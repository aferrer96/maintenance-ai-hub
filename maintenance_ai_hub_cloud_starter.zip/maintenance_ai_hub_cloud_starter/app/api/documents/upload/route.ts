import { NextResponse } from "next/server";

export async function POST() {
  return NextResponse.json({
    message: "Document upload is handled by the server action in app/documents/page.tsx."
  });
}
