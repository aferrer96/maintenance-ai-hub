import { NextResponse } from "next/server";
import { openai } from "@/lib/openai";
import { supabaseAdmin } from "@/lib/supabaseClient";

export async function POST(req: Request) {
  try {
    const { question } = await req.json();

    const { data: docs } = await supabaseAdmin
      .from("documents")
      .select("title, category, extracted_text")
      .ilike("extracted_text", `%${question}%`)
      .limit(5);

    const { data: repairs } = await supabaseAdmin
      .from("repair_logs")
      .select("problem, cause, repair, parts_used, downtime_minutes")
      .or(`problem.ilike.%${question}%,cause.ilike.%${question}%,repair.ilike.%${question}%`)
      .limit(5);

    const context = `
DOCUMENTS:
${(docs || []).map((d: any) => `Title: ${d.title}\nCategory: ${d.category}\nText: ${(d.extracted_text || "").slice(0, 2500)}`).join("\n---\n")}

REPAIR LOGS:
${(repairs || []).map((r: any) => `Problem: ${r.problem}\nCause: ${r.cause}\nRepair: ${r.repair}\nParts: ${r.parts_used}\nDowntime: ${r.downtime_minutes}`).join("\n---\n")}
`;

    const response = await openai.responses.create({
      model: "gpt-5.5",
      input: `
You are a maintenance troubleshooting assistant for a food processing facility.

Use the provided context first. If context is weak, say what information is missing.
Always include:
1. Likely causes
2. First checks
3. Safe troubleshooting steps
4. Parts/tools to inspect
5. What to document in the work order or repair log

Safety rules:
- Always mention lockout/tagout before physical inspection or repair.
- Never suggest bypassing guards, interlocks, E-stops, or safety devices.
- Tell the user to verify with OEM manuals and company procedures.
- Consider sanitation, washdown, water intrusion, food-grade lubricants, and food safety.

Context:
${context}

Question:
${question}
`
    });

    return NextResponse.json({ answer: response.output_text });
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || "Troubleshooting request failed." },
      { status: 500 }
    );
  }
}
