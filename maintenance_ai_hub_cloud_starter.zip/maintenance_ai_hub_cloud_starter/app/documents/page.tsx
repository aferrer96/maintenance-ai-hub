import { supabaseAdmin } from "@/lib/supabaseClient";

async function uploadDocument(formData: FormData) {
  "use server";

  const file = formData.get("file") as File;
  const title = String(formData.get("title") || "");
  const category = String(formData.get("category") || "Manual");
  const equipment_id = String(formData.get("equipment_id") || "");

  if (!file || !title) return;

  const safeName = `${Date.now()}_${file.name.replaceAll(" ", "_")}`;
  const storagePath = `manuals/${safeName}`;

  const arrayBuffer = await file.arrayBuffer();

  await supabaseAdmin.storage
    .from("machine-documents")
    .upload(storagePath, Buffer.from(arrayBuffer), {
      contentType: file.type || "application/pdf"
    });

  await supabaseAdmin.from("documents").insert({
    title,
    category,
    equipment_id: equipment_id || null,
    storage_path: storagePath,
    extracted_text: ""
  });
}

export default async function DocumentsPage() {
  const { data: equipment } = await supabaseAdmin
    .from("equipment")
    .select("*")
    .order("name");

  const { data: documents } = await supabaseAdmin
    .from("documents")
    .select("*, equipment(name)")
    .order("created_at", { ascending: false });

  return (
    <>
      <section className="card">
        <h1>Documents</h1>
        <form action={uploadDocument}>
          <input name="title" placeholder="Document title" required />
          <select name="category">
            <option>Manual</option>
            <option>Schematic</option>
            <option>PM</option>
            <option>Parts List</option>
            <option>LOTO</option>
            <option>Troubleshooting Guide</option>
          </select>
          <select name="equipment_id">
            <option value="">No equipment selected</option>
            {(equipment || []).map((item: any) => (
              <option key={item.id} value={item.id}>{item.name}</option>
            ))}
          </select>
          <input type="file" name="file" required />
          <button type="submit">Upload Document</button>
        </form>
      </section>

      <section className="card">
        <h2>Uploaded Documents</h2>
        {(documents || []).map((doc: any) => (
          <div key={doc.id} style={{ borderBottom: "1px solid #ddd", padding: "12px 0" }}>
            <strong>{doc.title}</strong>
            <p>{doc.category} | {doc.equipment?.name || "No equipment linked"}</p>
            <small>{doc.storage_path}</small>
          </div>
        ))}
      </section>
    </>
  );
}
