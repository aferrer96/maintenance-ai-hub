import { supabaseAdmin } from "@/lib/supabaseClient";

async function addEquipment(formData: FormData) {
  "use server";

  await supabaseAdmin.from("equipment").insert({
    name: formData.get("name"),
    area: formData.get("area"),
    asset_number: formData.get("asset_number"),
    manufacturer: formData.get("manufacturer"),
    model: formData.get("model"),
    serial_number: formData.get("serial_number"),
    location: formData.get("location"),
    notes: formData.get("notes")
  });
}

export default async function EquipmentPage() {
  const { data } = await supabaseAdmin
    .from("equipment")
    .select("*")
    .order("name");

  return (
    <>
      <section className="card">
        <h1>Equipment</h1>
        <form action={addEquipment}>
          <input name="name" placeholder="Machine name" required />
          <input name="area" placeholder="Area" />
          <input name="asset_number" placeholder="Asset number" />
          <input name="manufacturer" placeholder="Manufacturer" />
          <input name="model" placeholder="Model" />
          <input name="serial_number" placeholder="Serial number" />
          <input name="location" placeholder="Location" />
          <textarea name="notes" placeholder="Notes" />
          <button type="submit">Add Equipment</button>
        </form>
      </section>

      <section className="card">
        <h2>Equipment List</h2>
        {(data || []).map((item: any) => (
          <div key={item.id} style={{ borderBottom: "1px solid #ddd", padding: "12px 0" }}>
            <strong>{item.name}</strong>
            <p>{item.area} | {item.asset_number} | {item.manufacturer} | {item.model}</p>
          </div>
        ))}
      </section>
    </>
  );
}
