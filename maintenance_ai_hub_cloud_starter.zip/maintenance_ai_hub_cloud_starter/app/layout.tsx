import "./globals.css";
import Link from "next/link";

export const metadata = {
  title: "Maintenance AI Hub",
  description: "Cloud maintenance troubleshooting and repair assistant",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <nav>
          <Link href="/">Dashboard</Link>
          <Link href="/equipment">Equipment</Link>
          <Link href="/documents">Documents</Link>
          <Link href="/troubleshoot">Troubleshoot</Link>
          <Link href="/repairs">Repairs</Link>
        </nav>
        <main>{children}</main>
      </body>
    </html>
  );
}
