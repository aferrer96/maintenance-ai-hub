export default function Home() {
  return (
    <>
      <section className="card">
        <h1>Maintenance AI Hub</h1>
        <p>
          Cloud-based maintenance troubleshooting, equipment knowledge, document storage,
          repair logging, and AI-assisted troubleshooting.
        </p>
      </section>

      <section className="grid">
        <div className="card">
          <h2>Equipment</h2>
          <p>Track machine name, asset number, area, model, serial number, and notes.</p>
        </div>

        <div className="card">
          <h2>Documents</h2>
          <p>Upload manuals, schematics, PM sheets, parts lists, and LOTO documents.</p>
        </div>

        <div className="card">
          <h2>AI Troubleshooting</h2>
          <p>Ask questions and generate safe troubleshooting steps from company-approved information.</p>
        </div>

        <div className="card">
          <h2>Repair Logs</h2>
          <p>Document issue, cause, repair, parts used, downtime, and safety notes.</p>
        </div>
      </section>
    </>
  );
}
