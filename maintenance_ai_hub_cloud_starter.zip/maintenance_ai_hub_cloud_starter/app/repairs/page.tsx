import { supabaseAdmin } from "@/lib/supabaseClient";

async function addRepair(formData: FormData) {
  "use server";

  await supabaseAdmin.from("repair_logs").insert({
    equipment_id: formData.get("equipment_id") || null,
    problem: formData.get("problem"),
    cause: formData.get("cause"),
    repair: formData.get("repair"),
    parts_used: formData.get("parts_used"),
    downtime_minutes: Number(formData.get("downtime_minutes") || 0),
    mechanic: formData.get("mechanic"),
    safety_notes: formData.get("safety_notes")
  });
}

export default async function RepairsPage() {
  const { data: equipment } = await supabaseAdmin.from("equipment").select("*").order("name");
  const { data: repairs } = await supabaseAdmin
    .from("repair_logs")
    .select("*, equipment(name)")
    .order("created_at", { ascending: false });

  return (
    <>
      <section className="card">
        <h1>Repair Logs</h1>
        <form action={addRepair}>
          <select name="equipment_id">
            <option value="">No equipment selected</option>
            {(equipment || []).map((item: any) => (
              <option key={item.id} value={item.id}>{item.name}</option>
            ))}
          </select>
          <textarea name="problem" placeholder="Problem / symptom" required />
          <textarea name="cause" placeholder="Cause found" />
          <textarea name="repair" placeholder="Repair performed" />
          <textarea name="parts_used" placeholder="Parts used" />
          <input name="downtime_minutes" type="number" placeholder="Downtime minutes" />
          <input name="mechanic" placeholder="Mechanic" />
          <textarea name="safety_notes" placeholder="Safety / LOTO / sanitation notes" />
          <button type="submit">Save Repair Log</button>
        </form>
      </section>

      <section className="card">
        <h2>Recent Repairs</h2>
        {(repairs || []).map((log: any) => (
          <div key={log.id} style={{ borderBottom: "1px solid #ddd", padding: "12px 0" }}>
            <strong>{log.equipment?.name || "No equipment linked"}</strong>
            <p><b>Problem:</b> {log.problem}</p>
            <p><b>Cause:</b> {log.cause}</p>
            <p><b>Repair:</b> {log.repair}</p>
            <p><b>Parts:</b> {log.parts_used} | <b>Downtime:</b> {log.downtime_minutes} min</p>
          </div>
        ))}
      </section>
    </>
  );
}
