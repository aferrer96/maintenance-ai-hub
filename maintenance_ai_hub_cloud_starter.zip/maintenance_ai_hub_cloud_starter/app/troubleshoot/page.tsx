"use client";

import { useState } from "react";

export default function TroubleshootPage() {
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit() {
    setLoading(true);
    setAnswer("");

    const res = await fetch("/api/troubleshoot", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ question })
    });

    const data = await res.json();
    setAnswer(data.answer || data.error || "No answer returned.");
    setLoading(false);
  }

  return (
    <section className="card">
      <h1>AI Troubleshooter</h1>
      <textarea
        value={question}
        onChange={(e) => setQuestion(e.target.value)}
        placeholder="Example: Conveyor keeps tripping overload. What should I check?"
      />
      <button onClick={submit} disabled={loading}>
        {loading ? "Thinking..." : "Generate Troubleshooting Help"}
      </button>

      {answer && (
        <div className="card" style={{ marginTop: 20 }}>
          <h2>AI Response</h2>
          <pre>{answer}</pre>
        </div>
      )}
    </section>
  );
}
