# Maintenance AI Hub - Full Cloud App

Working cloud demo for a centralized maintenance troubleshooting and repair system.

## Includes

- Equipment records
- PDF/manual/schematic upload
- Supabase Storage upload
- PDF text extraction using `pdf-parse`
- Supabase database tables
- Repair logs
- OpenAI troubleshooting assistant
- Predictive maintenance summary
- Single-page dashboard UI

## Required services

- Vercel
- Supabase
- OpenAI API key

## Setup

1. Create a Supabase project.
2. Go to SQL Editor and run `supabase/schema.sql`.
3. Create a private Storage bucket named `machine-documents`.
4. Add environment variables to Vercel:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY`
   - `OPENAI_API_KEY`
5. Push the unzipped project files to GitHub.
6. Deploy with Vercel.

## Safety

This app is a maintenance assistant. It does not replace OEM manuals, company procedures, lockout/tagout, food safety rules, or qualified maintenance judgment.
