import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";
import pdfParse from "pdf-parse";

export const runtime = "nodejs";

export async function GET() {
  const { data, error } = await supabaseAdmin
    .from("documents")
    .select("*, equipment(name)")
    .order("created_at", { ascending: false });

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ documents: data || [] });
}

export async function POST(req: Request) {
  try {
    const formData = await req.formData();

    const file = formData.get("file") as File;
    const title = String(formData.get("title") || "");
    const category = String(formData.get("category") || "");
    const equipment_id_raw = String(formData.get("equipment_id") || "");
    const manualText = String(formData.get("manual_text") || "");

    if (!file || !title) {
      return NextResponse.json({ error: "File and title are required." }, { status: 400 });
    }

    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);

    const safeFileName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
    const storagePath = `${Date.now()}_${safeFileName}`;

    const upload = await supabaseAdmin.storage
      .from("machine-documents")
      .upload(storagePath, buffer, {
        contentType: file.type || "application/octet-stream",
        upsert: false
      });

    if (upload.error) {
      return NextResponse.json({ error: upload.error.message }, { status: 500 });
    }

    let extractedText = manualText || "";

    if (!extractedText && file.type === "application/pdf") {
      try {
        const parsed = await pdfParse(buffer);
        extractedText = parsed.text || "";
      } catch {
        extractedText = "PDF uploaded, but automatic text extraction failed. Add key notes manually or use OCR in a future version.";
      }
    }

    const { data, error } = await supabaseAdmin
      .from("documents")
      .insert({
        equipment_id: equipment_id_raw || null,
        title,
        category,
        file_name: file.name,
        storage_path: storagePath,
        extracted_text: extractedText
      })
      .select()
      .single();

    if (error) return NextResponse.json({ error: error.message }, { status: 500 });

    return NextResponse.json({
      document: data,
      extracted_length: extractedText.length
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || "Upload failed." }, { status: 500 });
  }
}
