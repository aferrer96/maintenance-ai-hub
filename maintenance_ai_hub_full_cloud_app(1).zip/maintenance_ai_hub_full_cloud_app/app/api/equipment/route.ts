import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";

export async function GET() {
  const { data, error } = await supabaseAdmin
    .from("equipment")
    .select("*")
    .order("created_at", { ascending: false });

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ equipment: data || [] });
}

export async function POST(req: Request) {
  const body = await req.json();

  const { data, error } = await supabaseAdmin
    .from("equipment")
    .insert({
      name: body.name,
      area: body.area || "",
      asset_number: body.asset_number || "",
      manufacturer: body.manufacturer || "",
      model: body.model || "",
      serial_number: body.serial_number || "",
      location: body.location || "",
      notes: body.notes || ""
    })
    .select()
    .single();

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ equipment: data });
}
