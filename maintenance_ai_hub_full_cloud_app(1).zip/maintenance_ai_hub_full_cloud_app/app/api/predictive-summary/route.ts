import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";
import { openai } from "@/lib/openaiClient";

export async function GET() {
  try {
    const { data: equipment } = await supabaseAdmin
      .from("equipment")
      .select("*")
      .limit(50);

    const { data: repairs } = await supabaseAdmin
      .from("repair_logs")
      .select("*, equipment(name)")
      .order("created_at", { ascending: false })
      .limit(100);

    const repairContext = (repairs || []).map((r: any) => `
Equipment: ${r.equipment?.name || "Unknown"}
Problem: ${r.problem}
Cause: ${r.cause}
Repair: ${r.repair}
Parts: ${r.parts_used}
Downtime: ${r.downtime_minutes}
Safety notes: ${r.safety_notes}
`).join("\n---\n");

    const response = await openai.responses.create({
      model: "gpt-5.5",
      input: `
You are a maintenance reliability assistant.

Create a predictive maintenance summary from this equipment and repair history.

Equipment count: ${(equipment || []).length}

Repair history:
${repairContext}

Return:
1. Equipment at risk
2. Repeat failure patterns
3. PM opportunities
4. Parts to stock
5. Downtime concerns
6. Recommended next actions

Keep it professional and useful for a maintenance supervisor or industrial mechanic.
`
    });

    return NextResponse.json({ summary: response.output_text });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || "Predictive summary failed." }, { status: 500 });
  }
}
