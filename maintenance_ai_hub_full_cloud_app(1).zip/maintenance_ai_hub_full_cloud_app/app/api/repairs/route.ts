import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";

export async function GET() {
  const { data, error } = await supabaseAdmin
    .from("repair_logs")
    .select("*, equipment(name)")
    .order("created_at", { ascending: false });

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ repairs: data || [] });
}

export async function POST(req: Request) {
  const body = await req.json();

  const { data, error } = await supabaseAdmin
    .from("repair_logs")
    .insert({
      equipment_id: body.equipment_id || null,
      problem: body.problem,
      cause: body.cause || "",
      repair: body.repair || "",
      parts_used: body.parts_used || "",
      downtime_minutes: Number(body.downtime_minutes || 0),
      mechanic: body.mechanic || "",
      safety_notes: body.safety_notes || ""
    })
    .select()
    .single();

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ repair: data });
}
