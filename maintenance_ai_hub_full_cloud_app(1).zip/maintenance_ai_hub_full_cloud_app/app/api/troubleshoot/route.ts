import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";
import { openai } from "@/lib/openaiClient";

function scoreText(text: string, question: string) {
  const words = question
    .toLowerCase()
    .split(/\W+/)
    .filter((w) => w.length > 3);

  const lower = text.toLowerCase();
  let score = 0;

  for (const word of words) {
    if (lower.includes(word)) score += 1;
  }

  return score;
}

export async function POST(req: Request) {
  try {
    const { question, equipment_id } = await req.json();

    if (!question) {
      return NextResponse.json({ error: "Question is required." }, { status: 400 });
    }

    let docsQuery = supabaseAdmin
      .from("documents")
      .select("title, category, extracted_text, equipment_id")
      .limit(50);

    if (equipment_id) {
      docsQuery = docsQuery.eq("equipment_id", equipment_id);
    }

    const { data: docs } = await docsQuery;

    let repairQuery = supabaseAdmin
      .from("repair_logs")
      .select("problem, cause, repair, parts_used, downtime_minutes, safety_notes, equipment_id")
      .limit(50);

    if (equipment_id) {
      repairQuery = repairQuery.eq("equipment_id", equipment_id);
    }

    const { data: repairs } = await repairQuery;

    const scoredDocs = (docs || [])
      .map((d: any) => ({
        ...d,
        score: scoreText(`${d.title} ${d.category} ${d.extracted_text || ""}`, question)
      }))
      .sort((a: any, b: any) => b.score - a.score)
      .slice(0, 5);

    const scoredRepairs = (repairs || [])
      .map((r: any) => ({
        ...r,
        score: scoreText(`${r.problem} ${r.cause} ${r.repair} ${r.parts_used}`, question)
      }))
      .sort((a: any, b: any) => b.score - a.score)
      .slice(0, 5);

    const context = `
DOCUMENT CONTEXT:
${scoredDocs.map((d: any) => `
Title: ${d.title}
Category: ${d.category}
Relevant text:
${(d.extracted_text || "").slice(0, 3500)}
`).join("\n---\n")}

REPAIR HISTORY:
${scoredRepairs.map((r: any) => `
Problem: ${r.problem}
Cause: ${r.cause}
Repair: ${r.repair}
Parts: ${r.parts_used}
Downtime: ${r.downtime_minutes}
Safety notes: ${r.safety_notes}
`).join("\n---\n")}
`;

    const response = await openai.responses.create({
      model: "gpt-5.5",
      input: `
You are an industrial maintenance troubleshooting assistant for a food processing / meat processing facility.

Use the provided machine manual/document/repair-log context first.
If the context does not contain enough information, say what is missing and give a safe general maintenance approach.

Question:
${question}

Context:
${context}

Your answer must include:
1. Most likely causes
2. First checks
3. Safe troubleshooting sequence
4. Components/parts/tools to inspect
5. What to document in the repair log
6. When to escalate

Safety rules:
- Always mention lockout/tagout before physical inspection or repair.
- Never suggest bypassing guards, safety interlocks, E-stops, or machine guarding.
- Tell the user to verify with OEM manuals, company procedures, and qualified maintenance judgment.
- Consider sanitation, washdown, water intrusion, food safety, and food-grade lubrication.
- Be practical for an industrial mechanic.
`
    });

    return NextResponse.json({
      answer: response.output_text,
      context_used: {
        documents: scoredDocs.map((d: any) => d.title),
        repairs: scoredRepairs.map((r: any) => r.problem)
      }
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || "Troubleshooting failed." }, { status: 500 });
  }
}
