import "./globals.css";

export const metadata = {
  title: "Maintenance AI Hub",
  description: "AI-powered maintenance troubleshooting and repair system"
};

export default function RootLayout({
  children
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
