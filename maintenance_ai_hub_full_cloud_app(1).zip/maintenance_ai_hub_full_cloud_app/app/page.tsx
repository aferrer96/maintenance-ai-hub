"use client";

import { useEffect, useState } from "react";

type Equipment = {
  id: string;
  name: string;
  area?: string;
  asset_number?: string;
  manufacturer?: string;
  model?: string;
  serial_number?: string;
  location?: string;
  notes?: string;
};

type DocumentRecord = {
  id: string;
  title: string;
  category?: string;
  file_name?: string;
  storage_path?: string;
  extracted_text?: string;
  equipment?: { name: string };
};

type RepairLog = {
  id: string;
  problem: string;
  cause?: string;
  repair?: string;
  parts_used?: string;
  downtime_minutes?: number;
  mechanic?: string;
  safety_notes?: string;
  equipment?: { name: string };
};

export default function Home() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [equipment, setEquipment] = useState<Equipment[]>([]);
  const [documents, setDocuments] = useState<DocumentRecord[]>([]);
  const [repairs, setRepairs] = useState<RepairLog[]>([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  const [question, setQuestion] = useState("");
  const [selectedEquipmentId, setSelectedEquipmentId] = useState("");
  const [aiAnswer, setAiAnswer] = useState("");
  const [predictiveSummary, setPredictiveSummary] = useState("");

  async function loadAll() {
    const [eqRes, docRes, repRes] = await Promise.all([
      fetch("/api/equipment"),
      fetch("/api/documents"),
      fetch("/api/repairs")
    ]);

    const eqData = await eqRes.json();
    const docData = await docRes.json();
    const repData = await repRes.json();

    setEquipment(eqData.equipment || []);
    setDocuments(docData.documents || []);
    setRepairs(repData.repairs || []);
  }

  useEffect(() => {
    loadAll();
  }, []);

  async function addEquipment(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    setMessage("");

    const form = new FormData(e.currentTarget);
    const payload = Object.fromEntries(form.entries());

    const res = await fetch("/api/equipment", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    const data = await res.json();
    setLoading(false);

    if (data.error) {
      setMessage(data.error);
      return;
    }

    setMessage("Equipment added.");
    e.currentTarget.reset();
    await loadAll();
  }

  async function uploadDocument(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    setMessage("");

    const form = new FormData(e.currentTarget);

    const res = await fetch("/api/documents", {
      method: "POST",
      body: form
    });

    const data = await res.json();
    setLoading(false);

    if (data.error) {
      setMessage(data.error);
      return;
    }

    setMessage(`Document uploaded. Extracted text length: ${data.extracted_length}`);
    e.currentTarget.reset();
    await loadAll();
  }

  async function addRepair(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    setMessage("");

    const form = new FormData(e.currentTarget);
    const payload = Object.fromEntries(form.entries());

    const res = await fetch("/api/repairs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    const data = await res.json();
    setLoading(false);

    if (data.error) {
      setMessage(data.error);
      return;
    }

    setMessage("Repair log saved.");
    e.currentTarget.reset();
    await loadAll();
  }

  async function troubleshoot() {
    setLoading(true);
    setAiAnswer("");
    setMessage("");

    const res = await fetch("/api/troubleshoot", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        question,
        equipment_id: selectedEquipmentId || null
      })
    });

    const data = await res.json();
    setLoading(false);

    if (data.error) {
      setMessage(data.error);
      return;
    }

    setAiAnswer(data.answer);
  }

  async function generatePredictiveSummary() {
    setLoading(true);
    setPredictiveSummary("");
    setMessage("");

    const res = await fetch("/api/predictive-summary");
    const data = await res.json();

    setLoading(false);

    if (data.error) {
      setMessage(data.error);
      return;
    }

    setPredictiveSummary(data.summary);
  }

  return (
    <main className="appShell">
      <header className="topbar">
        <div>
          <h1>Maintenance AI Hub</h1>
          <p>Centralized maintenance troubleshooting, machine PDFs, schematics, repairs, and AI support.</p>
        </div>
        <button onClick={loadAll} className="lightButton">Refresh</button>
      </header>

      <div className="layout">
        <aside className="sidebar">
          <button onClick={() => setActiveTab("dashboard")}>Dashboard</button>
          <button onClick={() => setActiveTab("equipment")}>Equipment</button>
          <button onClick={() => setActiveTab("documents")}>Documents / Uploads</button>
          <button onClick={() => setActiveTab("troubleshoot")}>AI Troubleshooter</button>
          <button onClick={() => setActiveTab("repairs")}>Repair Logs</button>
          <button onClick={() => setActiveTab("predictive")}>Predictive Summary</button>
        </aside>

        <section className="content">
          {message && <div className="message">{message}</div>}
          {loading && <div className="message">Working...</div>}

          {activeTab === "dashboard" && (
            <>
              <div className="stats">
                <div className="card"><h3>Equipment</h3><h2>{equipment.length}</h2></div>
                <div className="card"><h3>Documents</h3><h2>{documents.length}</h2></div>
                <div className="card"><h3>Repair Logs</h3><h2>{repairs.length}</h2></div>
                <div className="card"><h3>System</h3><h2>Cloud</h2></div>
              </div>

              <div className="panel">
                <h2>How this system works</h2>
                <p>
                  Add equipment, upload PDFs/manuals/schematics, log repairs, then ask the AI assistant
                  maintenance questions based on the uploaded documents and repair history.
                </p>
              </div>

              <div className="panel">
                <h2>Demo starting point</h2>
                <p>
                  Add Multivac #5 as the first equipment record, upload the four Multivac PDFs, then test the
                  AI troubleshooter with questions about vacuum, sealing, sensors, pneumatic cylinders, and repairs.
                </p>
              </div>
            </>
          )}

          {activeTab === "equipment" && (
            <div className="panel">
              <h2>Add Equipment</h2>
              <form onSubmit={addEquipment} className="formGrid">
                <input name="name" placeholder="Machine name, example: Multivac #5" required />
                <input name="area" placeholder="Area, example: Packaging" />
                <input name="asset_number" placeholder="Asset number" />
                <input name="manufacturer" placeholder="Manufacturer" />
                <input name="model" placeholder="Model" />
                <input name="serial_number" placeholder="Serial number" />
                <input name="location" placeholder="Location" />
                <textarea name="notes" placeholder="Notes" />
                <button>Add Equipment</button>
              </form>

              <h2>Equipment List</h2>
              {equipment.map((item) => (
                <div className="record" key={item.id}>
                  <h3>{item.name}</h3>
                  <p><b>Area:</b> {item.area || "-"}</p>
                  <p><b>Manufacturer:</b> {item.manufacturer || "-"} | <b>Model:</b> {item.model || "-"} | <b>Serial:</b> {item.serial_number || "-"}</p>
                  <p><b>Notes:</b> {item.notes || "-"}</p>
                </div>
              ))}
            </div>
          )}

          {activeTab === "documents" && (
            <div className="panel">
              <h2>Upload Documents</h2>
              <form onSubmit={uploadDocument} className="formGrid">
                <input name="title" placeholder="Document title" required />
                <select name="category">
                  <option>Manual</option>
                  <option>Schematic</option>
                  <option>Parts List</option>
                  <option>PM</option>
                  <option>LOTO</option>
                  <option>Troubleshooting Guide</option>
                </select>
                <select name="equipment_id">
                  <option value="">Link to equipment</option>
                  {equipment.map((item) => (
                    <option key={item.id} value={item.id}>{item.name}</option>
                  ))}
                </select>
                <input name="file" type="file" required />
                <textarea
                  name="manual_text"
                  placeholder="Optional: paste key notes here if the PDF is scanned or extraction fails."
                />
                <button>Upload Document</button>
              </form>

              <h2>Document Library</h2>
              {documents.map((doc) => (
                <div className="record" key={doc.id}>
                  <h3>{doc.title}</h3>
                  <p><b>Category:</b> {doc.category || "-"} | <b>Equipment:</b> {doc.equipment?.name || "-"}</p>
                  <p><b>File:</b> {doc.file_name || "-"} | <b>Storage:</b> {doc.storage_path}</p>
                  <p><b>Extracted text:</b> {(doc.extracted_text || "").length} characters</p>
                </div>
              ))}
            </div>
          )}

          {activeTab === "troubleshoot" && (
            <div className="panel">
              <h2>AI Troubleshooter</h2>
              <select value={selectedEquipmentId} onChange={(e) => setSelectedEquipmentId(e.target.value)}>
                <option value="">Search all equipment</option>
                {equipment.map((item) => (
                  <option key={item.id} value={item.id}>{item.name}</option>
                ))}
              </select>
              <textarea
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder="Example: Multivac #5 is not pulling full vacuum. What should I check?"
              />
              <button onClick={troubleshoot}>Generate AI Troubleshooting Response</button>

              {aiAnswer && (
                <div className="aiBox">
                  <pre>{aiAnswer}</pre>
                </div>
              )}
            </div>
          )}

          {activeTab === "repairs" && (
            <div className="panel">
              <h2>Add Repair Log</h2>
              <form onSubmit={addRepair} className="formGrid">
                <select name="equipment_id">
                  <option value="">Link to equipment</option>
                  {equipment.map((item) => (
                    <option key={item.id} value={item.id}>{item.name}</option>
                  ))}
                </select>
                <textarea name="problem" placeholder="Problem / symptom" required />
                <textarea name="cause" placeholder="Cause found" />
                <textarea name="repair" placeholder="Repair performed" />
                <textarea name="parts_used" placeholder="Parts used" />
                <input name="downtime_minutes" type="number" placeholder="Downtime minutes" />
                <input name="mechanic" placeholder="Mechanic" />
                <textarea name="safety_notes" placeholder="Safety / LOTO / sanitation notes" />
                <button>Save Repair Log</button>
              </form>

              <h2>Repair History</h2>
              {repairs.map((r) => (
                <div className="record" key={r.id}>
                  <h3>{r.equipment?.name || "Unlinked Equipment"}</h3>
                  <p><b>Problem:</b> {r.problem}</p>
                  <p><b>Cause:</b> {r.cause || "-"}</p>
                  <p><b>Repair:</b> {r.repair || "-"}</p>
                  <p><b>Parts:</b> {r.parts_used || "-"} | <b>Downtime:</b> {r.downtime_minutes || 0} min</p>
                  <p><b>Safety:</b> {r.safety_notes || "-"}</p>
                </div>
              ))}
            </div>
          )}

          {activeTab === "predictive" && (
            <div className="panel">
              <h2>Predictive Maintenance Summary</h2>
              <p>
                This uses repair history and equipment records to generate a supervisor-style maintenance summary.
              </p>
              <button onClick={generatePredictiveSummary}>Generate Predictive Summary</button>

              {predictiveSummary && (
                <div className="aiBox">
                  <pre>{predictiveSummary}</pre>
                </div>
              )}
            </div>
          )}
        </section>
      </div>
    </main>
  );
}
